import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../683aa047-8043-40f8-8d31-beb7ab1b138c/src/item"
import Script2 from "../1ab2733f-1782-4521-9eda-6aa8ad684277/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const rightsideWindowsGl = new Entity('rightsideWindowsGl')
engine.addEntity(rightsideWindowsGl)
rightsideWindowsGl.setParent(_scene)
const transform2 = new Transform({
  position: new Vector3(48, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rightsideWindowsGl.addComponentOrReplace(transform2)
const gltfShape = new GLTFShape("models/rightside_windows_glb.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
rightsideWindowsGl.addComponentOrReplace(gltfShape)

const leftsideWindowsGlb = new Entity('leftsideWindowsGlb')
engine.addEntity(leftsideWindowsGlb)
leftsideWindowsGlb.setParent(_scene)
const transform3 = new Transform({
  position: new Vector3(48, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
leftsideWindowsGlb.addComponentOrReplace(transform3)
const gltfShape2 = new GLTFShape("models/leftside_windows_glb.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
leftsideWindowsGlb.addComponentOrReplace(gltfShape2)

const museumGrassEdgesG = new Entity('museumGrassEdgesG')
engine.addEntity(museumGrassEdgesG)
museumGrassEdgesG.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(48, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 0.5285680294036865, 1)
})
museumGrassEdgesG.addComponentOrReplace(transform4)
const gltfShape3 = new GLTFShape("models/museum_grass_edges_glb.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
museumGrassEdgesG.addComponentOrReplace(gltfShape3)

const doorLeftGlb = new Entity('doorLeftGlb')
engine.addEntity(doorLeftGlb)
doorLeftGlb.setParent(_scene)
const transform5 = new Transform({
  position: new Vector3(44.69679641723633, 0, 20.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1.0446982383728027, 1)
})
doorLeftGlb.addComponentOrReplace(transform5)
const gltfShape4 = new GLTFShape("models/door_left_glb.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
doorLeftGlb.addComponentOrReplace(gltfShape4)

const doorRightGlb = new Entity('doorRightGlb')
engine.addEntity(doorRightGlb)
doorRightGlb.setParent(_scene)
const transform6 = new Transform({
  position: new Vector3(44.69679641723633, 0, 25.328369140625),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1.0446982383728027, 1)
})
doorRightGlb.addComponentOrReplace(transform6)
const gltfShape5 = new GLTFShape("models/door_right_glb.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
doorRightGlb.addComponentOrReplace(gltfShape5)

const tools = new Entity('tools')
engine.addEntity(tools)
tools.setParent(_scene)
const transform7 = new Transform({
  position: new Vector3(46.5, 0, 2.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
tools.addComponentOrReplace(transform7)

const triggerArea = new Entity('triggerArea')
engine.addEntity(triggerArea)
triggerArea.setParent(_scene)
const transform8 = new Transform({
  position: new Vector3(44.8776741027832, 0, 22.997636795043945),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(6.2331461906433105, 2.9211044311523438, 11.297411918640137)
})
triggerArea.addComponentOrReplace(transform8)

const rockGlb = new Entity('rockGlb')
engine.addEntity(rockGlb)
rockGlb.setParent(_scene)
const transform9 = new Transform({
  position: new Vector3(32.03468322753906, 0, 44.06332015991211),
  rotation: new Quaternion(-1.1729788486542804e-15, 0.045922305434942245, -5.474357411827668e-9, 0.9989450573921204),
  scale: new Vector3(1.2143200635910034, 1.2160491943359375, 0.807632565498352)
})
rockGlb.addComponentOrReplace(transform9)
const gltfShape6 = new GLTFShape("models/rock_02_glb.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
rockGlb.addComponentOrReplace(gltfShape6)

const bushGlb2 = new Entity('bushGlb2')
engine.addEntity(bushGlb2)
bushGlb2.setParent(_scene)
const gltfShape7 = new GLTFShape("models/bush_01_glb.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
bushGlb2.addComponentOrReplace(gltfShape7)
const transform10 = new Transform({
  position: new Vector3(33.95276641845703, 0, 43.53855514526367),
  rotation: new Quaternion(-4.724891657803152e-16, 0.9977964162826538, -1.1894658769051603e-7, 0.06635086238384247),
  scale: new Vector3(0.7506244778633118, 0.7506118416786194, 0.7506244778633118)
})
bushGlb2.addComponentOrReplace(transform10)

const treeAltGlb = new Entity('treeAltGlb')
engine.addEntity(treeAltGlb)
treeAltGlb.setParent(_scene)
const transform11 = new Transform({
  position: new Vector3(14.184783935546875, 0, 54.31108474731445),
  rotation: new Quaternion(3.3232768585261037e-16, 0.47128331661224365, -5.618134224505411e-8, 0.8819819092750549),
  scale: new Vector3(1.000001072883606, 1, 1.000001072883606)
})
treeAltGlb.addComponentOrReplace(transform11)
const gltfShape8 = new GLTFShape("models/tree_02_alt3_glb.glb")
gltfShape8.withCollisions = true
gltfShape8.isPointerBlocker = true
gltfShape8.visible = true
treeAltGlb.addComponentOrReplace(gltfShape8)

const bushGlb4 = new Entity('bushGlb4')
engine.addEntity(bushGlb4)
bushGlb4.setParent(_scene)
bushGlb4.addComponentOrReplace(gltfShape7)
const transform12 = new Transform({
  position: new Vector3(13.823466300964355, 0, 52.194339752197266),
  rotation: new Quaternion(-1.7157126685086316e-15, -0.9994027614593506, 1.1913807185237602e-7, 0.03455676510930061),
  scale: new Vector3(1.1390026807785034, 1.1390025615692139, 1.1390026807785034)
})
bushGlb4.addComponentOrReplace(transform12)

const bushGlb5 = new Entity('bushGlb5')
engine.addEntity(bushGlb5)
bushGlb5.setParent(_scene)
bushGlb5.addComponentOrReplace(gltfShape7)
const transform13 = new Transform({
  position: new Vector3(12.830598831176758, 0, 55.57125473022461),
  rotation: new Quaternion(1.0867946226996946e-15, -0.877299427986145, 1.0458222021725305e-7, -0.47994357347488403),
  scale: new Vector3(1.8388466835021973, 1.5029429197311401, 1.8039835691452026)
})
bushGlb5.addComponentOrReplace(transform13)

const pathAltGlb2 = new Entity('pathAltGlb2')
engine.addEntity(pathAltGlb2)
pathAltGlb2.setParent(_scene)
const gltfShape9 = new GLTFShape("models/path_03_alt_glb.glb")
gltfShape9.withCollisions = true
gltfShape9.isPointerBlocker = true
gltfShape9.visible = true
pathAltGlb2.addComponentOrReplace(gltfShape9)
const transform14 = new Transform({
  position: new Vector3(38.35309600830078, 0, 54.363338470458984),
  rotation: new Quaternion(2.0720620234569167e-16, 0.6146830916404724, -7.327592754791112e-8, 0.7887742519378662),
  scale: new Vector3(1.5000004768371582, 1.5, 1.5000004768371582)
})
pathAltGlb2.addComponentOrReplace(transform14)

const pathAltGlb3 = new Entity('pathAltGlb3')
engine.addEntity(pathAltGlb3)
pathAltGlb3.setParent(_scene)
pathAltGlb3.addComponentOrReplace(gltfShape9)
const transform15 = new Transform({
  position: new Vector3(35.50215148925781, 0, 55.10713577270508),
  rotation: new Quaternion(1.562106970469032e-14, 0.7624043226242065, -9.088567054504892e-8, -0.6471009254455566),
  scale: new Vector3(1.500002384185791, 1.5, 1.500002384185791)
})
pathAltGlb3.addComponentOrReplace(transform15)

const pathAltGlb4 = new Entity('pathAltGlb4')
engine.addEntity(pathAltGlb4)
pathAltGlb4.setParent(_scene)
pathAltGlb4.addComponentOrReplace(gltfShape9)
const transform16 = new Transform({
  position: new Vector3(31.984542846679688, 0, 53.58475112915039),
  rotation: new Quaternion(1.2206150286957966e-15, -0.2202281355857849, 2.6253205831494597e-8, -0.9754483699798584),
  scale: new Vector3(1.5000030994415283, 1.5, 1.5000030994415283)
})
pathAltGlb4.addComponentOrReplace(transform16)

const pathAltGlb5 = new Entity('pathAltGlb5')
engine.addEntity(pathAltGlb5)
pathAltGlb5.setParent(_scene)
pathAltGlb5.addComponentOrReplace(gltfShape9)
const transform17 = new Transform({
  position: new Vector3(29.555761337280273, 0, 52.2958869934082),
  rotation: new Quaternion(-2.7682615585684217e-14, -0.9014162421226501, 1.0745718270754878e-7, 0.43295347690582275),
  scale: new Vector3(1.5000051259994507, 1.5, 1.5000051259994507)
})
pathAltGlb5.addComponentOrReplace(transform17)

const pathAltGlb6 = new Entity('pathAltGlb6')
engine.addEntity(pathAltGlb6)
pathAltGlb6.setParent(_scene)
pathAltGlb6.addComponentOrReplace(gltfShape9)
const transform18 = new Transform({
  position: new Vector3(26.748380661010742, 0, 49.872230529785156),
  rotation: new Quaternion(1.0819328653406918e-15, 0.24222707748413086, -2.887568761877901e-8, 0.970219612121582),
  scale: new Vector3(1.5000050067901611, 1.5, 1.5000050067901611)
})
pathAltGlb6.addComponentOrReplace(transform18)

const pathAltGlb = new Entity('pathAltGlb')
engine.addEntity(pathAltGlb)
pathAltGlb.setParent(_scene)
pathAltGlb.addComponentOrReplace(gltfShape9)
const transform19 = new Transform({
  position: new Vector3(23.70044708251953, 0, 49.15866470336914),
  rotation: new Quaternion(1.429581211981161e-14, 0.5057873725891113, -6.029456756095897e-8, -0.8626582026481628),
  scale: new Vector3(1.6251294612884521, 1.6251239776611328, 1.6251294612884521)
})
pathAltGlb.addComponentOrReplace(transform19)

const pathAltGlb7 = new Entity('pathAltGlb7')
engine.addEntity(pathAltGlb7)
pathAltGlb7.setParent(_scene)
pathAltGlb7.addComponentOrReplace(gltfShape9)
const transform20 = new Transform({
  position: new Vector3(20.05525779724121, 0, 49.67292404174805),
  rotation: new Quaternion(-2.669054010467388e-14, -0.9837548136711121, 1.1727267690275767e-7, -0.17951762676239014),
  scale: new Vector3(1.6251308917999268, 1.6251239776611328, 1.6251308917999268)
})
pathAltGlb7.addComponentOrReplace(transform20)

const pathAltGlb8 = new Entity('pathAltGlb8')
engine.addEntity(pathAltGlb8)
pathAltGlb8.setParent(_scene)
pathAltGlb8.addComponentOrReplace(gltfShape9)
const transform21 = new Transform({
  position: new Vector3(16.249908447265625, 0, 48.844276428222656),
  rotation: new Quaternion(-1.5879112786357187e-15, 0.28771570324897766, -3.4298341944349886e-8, 0.9577159285545349),
  scale: new Vector3(1.6251320838928223, 1.6251239776611328, 1.6251320838928223)
})
pathAltGlb8.addComponentOrReplace(transform21)

const pathAltGlb9 = new Entity('pathAltGlb9')
engine.addEntity(pathAltGlb9)
pathAltGlb9.setParent(_scene)
pathAltGlb9.addComponentOrReplace(gltfShape9)
const transform22 = new Transform({
  position: new Vector3(13.049419403076172, 0, 49.105133056640625),
  rotation: new Quaternion(-4.207169619738389e-14, -0.9985096454620361, 1.1903159702342236e-7, 0.0545772910118103),
  scale: new Vector3(1.625135064125061, 1.6251239776611328, 1.625135064125061)
})
pathAltGlb9.addComponentOrReplace(transform22)

const pathAltGlb10 = new Entity('pathAltGlb10')
engine.addEntity(pathAltGlb10)
pathAltGlb10.setParent(_scene)
pathAltGlb10.addComponentOrReplace(gltfShape9)
const transform23 = new Transform({
  position: new Vector3(10.225050926208496, 0, 49.99516296386719),
  rotation: new Quaternion(2.29419873262705e-14, 0.5019382238388062, -5.983572037848717e-8, -0.864903450012207),
  scale: new Vector3(1.6251369714736938, 1.6251239776611328, 1.6251369714736938)
})
pathAltGlb10.addComponentOrReplace(transform23)

const pathAltGlb11 = new Entity('pathAltGlb11')
engine.addEntity(pathAltGlb11)
pathAltGlb11.setParent(_scene)
pathAltGlb11.addComponentOrReplace(gltfShape9)
const transform24 = new Transform({
  position: new Vector3(6.710674285888672, 0, 50.589820861816406),
  rotation: new Quaternion(2.973889309722949e-14, 0.935515284538269, -1.1152207690656724e-7, 0.35328635573387146),
  scale: new Vector3(1.6251381635665894, 1.6251239776611328, 1.6251381635665894)
})
pathAltGlb11.addComponentOrReplace(transform24)

const pathAltGlb12 = new Entity('pathAltGlb12')
engine.addEntity(pathAltGlb12)
pathAltGlb12.setParent(_scene)
pathAltGlb12.addComponentOrReplace(gltfShape9)
const transform25 = new Transform({
  position: new Vector3(3.6821694374084473, 0, 48.46848678588867),
  rotation: new Quaternion(-4.694182478300448e-15, -0.028595533221960068, 3.4088847300495217e-9, 0.999591052532196),
  scale: new Vector3(1.6251391172409058, 1.6251239776611328, 1.6251391172409058)
})
pathAltGlb12.addComponentOrReplace(transform25)

const pathAltGlb13 = new Entity('pathAltGlb13')
engine.addEntity(pathAltGlb13)
pathAltGlb13.setParent(_scene)
pathAltGlb13.addComponentOrReplace(gltfShape9)
const transform26 = new Transform({
  position: new Vector3(1.9520454406738281, 0, 46.28351593017578),
  rotation: new Quaternion(-1.3590812198251753e-14, -0.7267085313796997, 8.663037220912884e-8, -0.6869459748268127),
  scale: new Vector3(1.3730006217956543, 1.372987985610962, 1.3730006217956543)
})
pathAltGlb13.addComponentOrReplace(transform26)

const pathAltGlb14 = new Entity('pathAltGlb14')
engine.addEntity(pathAltGlb14)
pathAltGlb14.setParent(_scene)
pathAltGlb14.addComponentOrReplace(gltfShape9)
const transform27 = new Transform({
  position: new Vector3(1.360407829284668, 0, 43.885318756103516),
  rotation: new Quaternion(1.9579412215337856e-14, 0.6719978451728821, -8.010839280814253e-8, -0.7405532002449036),
  scale: new Vector3(1.1031973361968994, 1.1031862497329712, 1.1031973361968994)
})
pathAltGlb14.addComponentOrReplace(transform27)

const pathAltGlb15 = new Entity('pathAltGlb15')
engine.addEntity(pathAltGlb15)
pathAltGlb15.setParent(_scene)
pathAltGlb15.addComponentOrReplace(gltfShape9)
const transform28 = new Transform({
  position: new Vector3(1.5166685581207275, 0, 41.52172088623047),
  rotation: new Quaternion(2.3024771244337452e-14, 0.8370459079742432, -9.978361958928872e-8, 0.5471326112747192),
  scale: new Vector3(1.1031986474990845, 1.1031862497329712, 1.1031986474990845)
})
pathAltGlb15.addComponentOrReplace(transform28)

const pathAltGlb16 = new Entity('pathAltGlb16')
engine.addEntity(pathAltGlb16)
pathAltGlb16.setParent(_scene)
pathAltGlb16.addComponentOrReplace(gltfShape9)
const transform29 = new Transform({
  position: new Vector3(1.5, 0, 38),
  rotation: new Quaternion(-5.204391503529655e-15, -0.17021022737026215, 2.0290665148081644e-8, 0.985407829284668),
  scale: new Vector3(1.1031982898712158, 1.1031862497329712, 1.1031982898712158)
})
pathAltGlb16.addComponentOrReplace(transform29)

const pathAltGlb17 = new Entity('pathAltGlb17')
engine.addEntity(pathAltGlb17)
pathAltGlb17.setParent(_scene)
pathAltGlb17.addComponentOrReplace(gltfShape9)
const transform30 = new Transform({
  position: new Vector3(1.4249224662780762, 0, 35.48419952392578),
  rotation: new Quaternion(-1.4306786278676237e-14, -0.5451127290725708, 6.498246563069188e-8, -0.8383628129959106),
  scale: new Vector3(1.04647958278656, 1.0464664697647095, 1.04647958278656)
})
pathAltGlb17.addComponentOrReplace(transform30)

const pathAltGlb18 = new Entity('pathAltGlb18')
engine.addEntity(pathAltGlb18)
pathAltGlb18.setParent(_scene)
pathAltGlb18.addComponentOrReplace(gltfShape9)
const transform31 = new Transform({
  position: new Vector3(1.5200610160827637, 0, 32.78411102294922),
  rotation: new Quaternion(1.79410777006268e-14, 0.439332515001297, -5.2372538306144634e-8, -0.8983245491981506),
  scale: new Vector3(1.0218007564544678, 1.0217888355255127, 1.0218007564544678)
})
pathAltGlb18.addComponentOrReplace(transform31)

const pathAltGlb19 = new Entity('pathAltGlb19')
engine.addEntity(pathAltGlb19)
pathAltGlb19.setParent(_scene)
pathAltGlb19.addComponentOrReplace(gltfShape9)
const transform32 = new Transform({
  position: new Vector3(1.5055854320526123, 0, 30.92357635498047),
  rotation: new Quaternion(2.669784152867921e-14, 0.9822895526885986, -1.1709801128745312e-7, 0.1873694807291031),
  scale: new Vector3(0.9220641255378723, 0.9220516681671143, 0.9220641255378723)
})
pathAltGlb19.addComponentOrReplace(transform32)

const rockGlb2 = new Entity('rockGlb2')
engine.addEntity(rockGlb2)
rockGlb2.setParent(_scene)
rockGlb2.addComponentOrReplace(gltfShape6)
const transform33 = new Transform({
  position: new Vector3(4.343527793884277, 0, 60.740867614746094),
  rotation: new Quaternion(-3.4511175824915048e-15, -0.30592405796051025, 3.646898960596445e-8, 0.9520559310913086),
  scale: new Vector3(1.4907898902893066, 1.4929125308990479, 0.9915085434913635)
})
rockGlb2.addComponentOrReplace(transform33)

const bushGlb6 = new Entity('bushGlb6')
engine.addEntity(bushGlb6)
bushGlb6.setParent(_scene)
bushGlb6.addComponentOrReplace(gltfShape7)
const transform34 = new Transform({
  position: new Vector3(30.392438888549805, 0, 43.8061637878418),
  rotation: new Quaternion(-0.018265416845679283, 0.23309260606765747, 0.16793794929981232, 0.9576696157455444),
  scale: new Vector3(0.8685334324836731, 0.8685208559036255, 0.8685331344604492)
})
bushGlb6.addComponentOrReplace(transform34)

const rockAltGlb = new Entity('rockAltGlb')
engine.addEntity(rockAltGlb)
rockAltGlb.setParent(_scene)
const transform35 = new Transform({
  position: new Vector3(10, 0, 45.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockAltGlb.addComponentOrReplace(transform35)
const gltfShape10 = new GLTFShape("models/rock_01_alt2_glb.glb")
gltfShape10.withCollisions = true
gltfShape10.isPointerBlocker = true
gltfShape10.visible = true
rockAltGlb.addComponentOrReplace(gltfShape10)

const rockAltGlb2 = new Entity('rockAltGlb2')
engine.addEntity(rockAltGlb2)
rockAltGlb2.setParent(_scene)
rockAltGlb2.addComponentOrReplace(gltfShape10)
const transform36 = new Transform({
  position: new Vector3(43.77657699584961, 0, 60.86866760253906),
  rotation: new Quaternion(-6.385191854418881e-15, 0.9611279368400574, -1.1457535720182932e-7, -0.276103675365448),
  scale: new Vector3(0.7112234830856323, 0.7112197875976562, 0.7112234830856323)
})
rockAltGlb2.addComponentOrReplace(transform36)

const logAltGlb = new Entity('logAltGlb')
engine.addEntity(logAltGlb)
logAltGlb.setParent(_scene)
const transform37 = new Transform({
  position: new Vector3(12.656159400939941, 0, 44.24185562133789),
  rotation: new Quaternion(-0.00555608794093132, -0.15057270228862762, -0.03645360469818115, 0.9879110455513),
  scale: new Vector3(1.2145386934280396, 1.21453857421875, 1.214538335800171)
})
logAltGlb.addComponentOrReplace(transform37)
const gltfShape11 = new GLTFShape("models/log_01_alt_glb.glb")
gltfShape11.withCollisions = true
gltfShape11.isPointerBlocker = true
gltfShape11.visible = true
logAltGlb.addComponentOrReplace(gltfShape11)

const logAltGlb2 = new Entity('logAltGlb2')
engine.addEntity(logAltGlb2)
logAltGlb2.setParent(_scene)
logAltGlb2.addComponentOrReplace(gltfShape11)
const transform38 = new Transform({
  position: new Vector3(40.14113235473633, 0, 60.072509765625),
  rotation: new Quaternion(-0.03840953856706619, 0.979676365852356, 0.05317249894142151, -0.18955670297145844),
  scale: new Vector3(1.2145426273345947, 1.214538335800171, 1.2145427465438843)
})
logAltGlb2.addComponentOrReplace(transform38)

const bushGlb = new Entity('bushGlb')
engine.addEntity(bushGlb)
bushGlb.setParent(_scene)
bushGlb.addComponentOrReplace(gltfShape7)
const transform39 = new Transform({
  position: new Vector3(41.7464714050293, 0, 62.012428283691406),
  rotation: new Quaternion(3.4417947143575503e-15, -0.9320081472396851, 1.1110402198255542e-7, -0.3624374568462372),
  scale: new Vector3(1.322995662689209, 0.9347655773162842, 1.322995662689209)
})
bushGlb.addComponentOrReplace(transform39)

const rockAltGlb3 = new Entity('rockAltGlb3')
engine.addEntity(rockAltGlb3)
rockAltGlb3.setParent(_scene)
rockAltGlb3.addComponentOrReplace(gltfShape10)
const transform40 = new Transform({
  position: new Vector3(16.6683292388916, 0, 54.674354553222656),
  rotation: new Quaternion(1.2696930705717764e-15, 0.9061957001686096, -1.0802693140021802e-7, -0.42285868525505066),
  scale: new Vector3(1.0000007152557373, 1, 1.0000007152557373)
})
rockAltGlb3.addComponentOrReplace(transform40)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape12 = new GLTFShape("models/ground_momus.glb")
gltfShape12.withCollisions = true
gltfShape12.isPointerBlocker = true
gltfShape12.visible = true
entity.addComponentOrReplace(gltfShape12)
const transform41 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform41)

const entity2 = new Entity('entity2')
engine.addEntity(entity2)
entity2.setParent(_scene)
entity2.addComponentOrReplace(gltfShape12)
const transform42 = new Transform({
  position: new Vector3(24, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity2.addComponentOrReplace(transform42)

const entity3 = new Entity('entity3')
engine.addEntity(entity3)
entity3.setParent(_scene)
entity3.addComponentOrReplace(gltfShape12)
const transform43 = new Transform({
  position: new Vector3(40, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity3.addComponentOrReplace(transform43)

const entity4 = new Entity('entity4')
engine.addEntity(entity4)
entity4.setParent(_scene)
entity4.addComponentOrReplace(gltfShape12)
const transform44 = new Transform({
  position: new Vector3(8, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity4.addComponentOrReplace(transform44)

const entity5 = new Entity('entity5')
engine.addEntity(entity5)
entity5.setParent(_scene)
entity5.addComponentOrReplace(gltfShape12)
const transform45 = new Transform({
  position: new Vector3(24, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity5.addComponentOrReplace(transform45)

const entity6 = new Entity('entity6')
engine.addEntity(entity6)
entity6.setParent(_scene)
entity6.addComponentOrReplace(gltfShape12)
const transform46 = new Transform({
  position: new Vector3(40, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity6.addComponentOrReplace(transform46)

const entity7 = new Entity('entity7')
engine.addEntity(entity7)
entity7.setParent(_scene)
entity7.addComponentOrReplace(gltfShape12)
const transform47 = new Transform({
  position: new Vector3(8, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity7.addComponentOrReplace(transform47)

const entity8 = new Entity('entity8')
engine.addEntity(entity8)
entity8.setParent(_scene)
entity8.addComponentOrReplace(gltfShape12)
const transform48 = new Transform({
  position: new Vector3(24, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity8.addComponentOrReplace(transform48)

const entity9 = new Entity('entity9')
engine.addEntity(entity9)
entity9.setParent(_scene)
entity9.addComponentOrReplace(gltfShape12)
const transform49 = new Transform({
  position: new Vector3(40, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity9.addComponentOrReplace(transform49)

const entity10 = new Entity('entity10')
engine.addEntity(entity10)
entity10.setParent(_scene)
entity10.addComponentOrReplace(gltfShape12)
const transform50 = new Transform({
  position: new Vector3(8, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity10.addComponentOrReplace(transform50)

const entity11 = new Entity('entity11')
engine.addEntity(entity11)
entity11.setParent(_scene)
entity11.addComponentOrReplace(gltfShape12)
const transform51 = new Transform({
  position: new Vector3(24, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity11.addComponentOrReplace(transform51)

const entity12 = new Entity('entity12')
engine.addEntity(entity12)
entity12.setParent(_scene)
entity12.addComponentOrReplace(gltfShape12)
const transform52 = new Transform({
  position: new Vector3(40, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity12.addComponentOrReplace(transform52)

const facespiecesGroupGl = new Entity('facespiecesGroupGl')
engine.addEntity(facespiecesGroupGl)
facespiecesGroupGl.setParent(_scene)
const transform53 = new Transform({
  position: new Vector3(8.242679595947266, 0, 22.809446334838867),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
facespiecesGroupGl.addComponentOrReplace(transform53)
const gltfShape13 = new GLTFShape("models/facesPieces_group_glb.glb")
gltfShape13.withCollisions = true
gltfShape13.isPointerBlocker = true
gltfShape13.visible = true
facespiecesGroupGl.addComponentOrReplace(gltfShape13)

const rightSideGroupGlb = new Entity('rightSideGroupGlb')
engine.addEntity(rightSideGroupGlb)
rightSideGroupGlb.setParent(_scene)
const transform54 = new Transform({
  position: new Vector3(25.525049209594727, 0.00032625533640384674, 40.19802474975586),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.0736207962036133, 1.0736207962036133, 1.0736207962036133)
})
rightSideGroupGlb.addComponentOrReplace(transform54)
const gltfShape14 = new GLTFShape("models/right_side_group_glb.glb")
gltfShape14.withCollisions = true
gltfShape14.isPointerBlocker = true
gltfShape14.visible = true
rightSideGroupGlb.addComponentOrReplace(gltfShape14)

const coldieBioFinalGlb = new Entity('coldieBioFinalGlb')
engine.addEntity(coldieBioFinalGlb)
coldieBioFinalGlb.setParent(_scene)
const transform55 = new Transform({
  position: new Vector3(4.0102219581604, 2.4300413131713867, 22.70284080505371),
  rotation: new Quaternion(-0.11745893955230713, -0.99307781457901, 1.2100950641524832e-7, -8.19482348646261e-9),
  scale: new Vector3(1.2102597951889038, 1.2102527618408203, 1.2102575302124023)
})
coldieBioFinalGlb.addComponentOrReplace(transform55)
const gltfShape15 = new GLTFShape("models/coldie_bio_final_glb.glb")
gltfShape15.withCollisions = true
gltfShape15.isPointerBlocker = true
gltfShape15.visible = true
coldieBioFinalGlb.addComponentOrReplace(gltfShape15)

const museumFrontWindows = new Entity('museumFrontWindows')
engine.addEntity(museumFrontWindows)
museumFrontWindows.setParent(_scene)
const transform56 = new Transform({
  position: new Vector3(46.5, 0, 0.9999999403953552),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
museumFrontWindows.addComponentOrReplace(transform56)
const gltfShape16 = new GLTFShape("models/museum_front_windows_final_glb.glb")
gltfShape16.withCollisions = true
gltfShape16.isPointerBlocker = true
gltfShape16.visible = true
museumFrontWindows.addComponentOrReplace(gltfShape16)

const coldieLogoGlb = new Entity('coldieLogoGlb')
engine.addEntity(coldieLogoGlb)
coldieLogoGlb.setParent(_scene)
const transform57 = new Transform({
  position: new Vector3(33.668399810791016, 3.1599655151367188, 23.03968048095703),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.8318111896514893, 1.8318023681640625, 1.8318111896514893)
})
coldieLogoGlb.addComponentOrReplace(transform57)
const gltfShape17 = new GLTFShape("models/coldie_logo_3_glb.glb")
gltfShape17.withCollisions = true
gltfShape17.isPointerBlocker = true
gltfShape17.visible = true
coldieLogoGlb.addComponentOrReplace(gltfShape17)

const coldieBenchGlb2 = new Entity('coldieBenchGlb2')
engine.addEntity(coldieBenchGlb2)
coldieBenchGlb2.setParent(_scene)
const gltfShape18 = new GLTFShape("models/coldie_bench_glb.glb")
gltfShape18.withCollisions = true
gltfShape18.isPointerBlocker = true
gltfShape18.visible = true
coldieBenchGlb2.addComponentOrReplace(gltfShape18)
const transform58 = new Transform({
  position: new Vector3(43.220890045166016, 0.09227490425109863, 13.723118782043457),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
coldieBenchGlb2.addComponentOrReplace(transform58)

const coldieBenchGlb4 = new Entity('coldieBenchGlb4')
engine.addEntity(coldieBenchGlb4)
coldieBenchGlb4.setParent(_scene)
coldieBenchGlb4.addComponentOrReplace(gltfShape18)
const transform59 = new Transform({
  position: new Vector3(28.226726531982422, 1.4693529605865479, 20.516223907470703),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000066757202148, 1, 1.0000066757202148)
})
coldieBenchGlb4.addComponentOrReplace(transform59)

const coldieTableGlb = new Entity('coldieTableGlb')
engine.addEntity(coldieTableGlb)
coldieTableGlb.setParent(_scene)
const transform60 = new Transform({
  position: new Vector3(28.196725845336914, 1.4370408058166504, 23),
  rotation: new Quaternion(4.483351213168524e-16, -0.7071068286895752, 8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(1.3327305316925049, 0.8136119842529297, 0.8136119842529297)
})
coldieTableGlb.addComponentOrReplace(transform60)
const gltfShape19 = new GLTFShape("models/coldie_table_glb.glb")
gltfShape19.withCollisions = true
gltfShape19.isPointerBlocker = true
gltfShape19.visible = true
coldieTableGlb.addComponentOrReplace(gltfShape19)

const coldieBenchGlb6 = new Entity('coldieBenchGlb6')
engine.addEntity(coldieBenchGlb6)
coldieBenchGlb6.setParent(_scene)
coldieBenchGlb6.addComponentOrReplace(gltfShape18)
const transform61 = new Transform({
  position: new Vector3(28.226726531982422, 1.4693529605865479, 25.388973236083984),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.000009298324585, 1, 1.000009298324585)
})
coldieBenchGlb6.addComponentOrReplace(transform61)

const coldieBenchGlb10 = new Entity('coldieBenchGlb10')
engine.addEntity(coldieBenchGlb10)
coldieBenchGlb10.setParent(_scene)
coldieBenchGlb10.addComponentOrReplace(gltfShape18)
const transform62 = new Transform({
  position: new Vector3(43.220890045166016, 0.09227490425109863, 10.222938537597656),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
coldieBenchGlb10.addComponentOrReplace(transform62)

const coldieBenchGlb3 = new Entity('coldieBenchGlb3')
engine.addEntity(coldieBenchGlb3)
coldieBenchGlb3.setParent(_scene)
coldieBenchGlb3.addComponentOrReplace(gltfShape18)
const transform63 = new Transform({
  position: new Vector3(30.726726531982422, 1.4693529605865479, 22.954143524169922),
  rotation: new Quaternion(-2.177062080483132e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(1.0000059604644775, 1, 1.0000059604644775)
})
coldieBenchGlb3.addComponentOrReplace(transform63)

const coldiePlantAltGlb = new Entity('coldiePlantAltGlb')
engine.addEntity(coldiePlantAltGlb)
coldiePlantAltGlb.setParent(_scene)
const transform64 = new Transform({
  position: new Vector3(21.5, 0.0902562141418457, 29.652429580688477),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.497243046760559, 1.497243046760559, 1.497243046760559)
})
coldiePlantAltGlb.addComponentOrReplace(transform64)
const gltfShape20 = new GLTFShape("models/coldie_plant_alt_glb.glb")
gltfShape20.withCollisions = true
gltfShape20.isPointerBlocker = true
gltfShape20.visible = true
coldiePlantAltGlb.addComponentOrReplace(gltfShape20)

const coldiePlantAltGlb2 = new Entity('coldiePlantAltGlb2')
engine.addEntity(coldiePlantAltGlb2)
coldiePlantAltGlb2.setParent(_scene)
coldiePlantAltGlb2.addComponentOrReplace(gltfShape20)
const transform65 = new Transform({
  position: new Vector3(21.5, 0.0902562141418457, 16.21360206604004),
  rotation: new Quaternion(-3.499301686970776e-16, -0.9891519546508789, 1.1791608756084315e-7, 0.14689593017101288),
  scale: new Vector3(1.4714813232421875, 1.4714808464050293, 1.4714813232421875)
})
coldiePlantAltGlb2.addComponentOrReplace(transform65)

const coldiePlantAltGlb3 = new Entity('coldiePlantAltGlb3')
engine.addEntity(coldiePlantAltGlb3)
coldiePlantAltGlb3.setParent(_scene)
coldiePlantAltGlb3.addComponentOrReplace(gltfShape20)
const transform66 = new Transform({
  position: new Vector3(3.533576011657715, 2.6642980575561523, 3.477128028869629),
  rotation: new Quaternion(-3.499301686970776e-16, -0.9891519546508789, 1.1791608756084315e-7, 0.14689593017101288),
  scale: new Vector3(0.9808377027511597, 0.980837345123291, 0.9808377027511597)
})
coldiePlantAltGlb3.addComponentOrReplace(transform66)

const coldiePlantAltGlb4 = new Entity('coldiePlantAltGlb4')
engine.addEntity(coldiePlantAltGlb4)
coldiePlantAltGlb4.setParent(_scene)
coldiePlantAltGlb4.addComponentOrReplace(gltfShape20)
const transform67 = new Transform({
  position: new Vector3(3.533576011657715, 2.6642980575561523, 42.261009216308594),
  rotation: new Quaternion(-3.7426389002447676e-16, -0.6958457231521606, 8.295126008306397e-8, 0.7181913256645203),
  scale: new Vector3(0.980837881565094, 0.980837345123291, 0.980837881565094)
})
coldiePlantAltGlb4.addComponentOrReplace(transform67)

const coldiePlantAltGlb5 = new Entity('coldiePlantAltGlb5')
engine.addEntity(coldiePlantAltGlb5)
coldiePlantAltGlb5.setParent(_scene)
coldiePlantAltGlb5.addComponentOrReplace(gltfShape20)
const transform68 = new Transform({
  position: new Vector3(44.22590255737305, 5.47256326675415, 42.261009216308594),
  rotation: new Quaternion(-3.9887653930140675e-15, -0.15606805682182312, 1.8604758622586814e-8, 0.9877463579177856),
  scale: new Vector3(1.3348020315170288, 1.3348000049591064, 1.3348020315170288)
})
coldiePlantAltGlb5.addComponentOrReplace(transform68)

const coldiePlantAltGlb7 = new Entity('coldiePlantAltGlb7')
engine.addEntity(coldiePlantAltGlb7)
coldiePlantAltGlb7.setParent(_scene)
coldiePlantAltGlb7.addComponentOrReplace(gltfShape20)
const transform69 = new Transform({
  position: new Vector3(44.22590255737305, 5.47256326675415, 3.679226875305176),
  rotation: new Quaternion(-1.1172522334170648e-15, -0.8841902017593384, 1.054036786740653e-7, 0.4671271741390228),
  scale: new Vector3(1.3348028659820557, 1.3348000049591064, 1.3348028659820557)
})
coldiePlantAltGlb7.addComponentOrReplace(transform69)

const coldiePlantAltGlb8 = new Entity('coldiePlantAltGlb8')
engine.addEntity(coldiePlantAltGlb8)
coldiePlantAltGlb8.setParent(_scene)
coldiePlantAltGlb8.addComponentOrReplace(gltfShape20)
const transform70 = new Transform({
  position: new Vector3(42.47472381591797, 0.10942769050598145, 4.993047714233398),
  rotation: new Quaternion(-1.2347251152893955e-15, -0.9999880790710449, 1.1920785425445501e-7, -0.004884927999228239),
  scale: new Vector3(1.6627625226974487, 1.6627519130706787, 1.6627625226974487)
})
coldiePlantAltGlb8.addComponentOrReplace(transform70)

const coldieBenchGlb5 = new Entity('coldieBenchGlb5')
engine.addEntity(coldieBenchGlb5)
coldieBenchGlb5.setParent(_scene)
coldieBenchGlb5.addComponentOrReplace(gltfShape18)
const transform71 = new Transform({
  position: new Vector3(33.21129608154297, 4.742791175842285, 41.935184478759766),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000123977661133, 1, 1.0000123977661133)
})
coldieBenchGlb5.addComponentOrReplace(transform71)

const coldieBenchGlb11 = new Entity('coldieBenchGlb11')
engine.addEntity(coldieBenchGlb11)
coldieBenchGlb11.setParent(_scene)
coldieBenchGlb11.addComponentOrReplace(gltfShape18)
const transform72 = new Transform({
  position: new Vector3(24.478023529052734, 4.225706100463867, 41.935184478759766),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.000014305114746, 1, 1.000014305114746)
})
coldieBenchGlb11.addComponentOrReplace(transform72)

const coldieBenchGlb12 = new Entity('coldieBenchGlb12')
engine.addEntity(coldieBenchGlb12)
coldieBenchGlb12.setParent(_scene)
coldieBenchGlb12.addComponentOrReplace(gltfShape18)
const transform73 = new Transform({
  position: new Vector3(15.779367446899414, 3.6912262439727783, 41.935184478759766),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000157356262207, 1, 1.0000157356262207)
})
coldieBenchGlb12.addComponentOrReplace(transform73)

const coldiePlantAltGlb6 = new Entity('coldiePlantAltGlb6')
engine.addEntity(coldiePlantAltGlb6)
coldiePlantAltGlb6.setParent(_scene)
coldiePlantAltGlb6.addComponentOrReplace(gltfShape20)
const transform74 = new Transform({
  position: new Vector3(42.47472381591797, 0.10942769050598145, 40.51996994018555),
  rotation: new Quaternion(-1.2347251152893955e-15, -0.9999880790710449, 1.1920785425445501e-7, -0.004884927999228239),
  scale: new Vector3(1.6627626419067383, 1.6627519130706787, 1.6627626419067383)
})
coldiePlantAltGlb6.addComponentOrReplace(transform74)

const coldieBenchGlb = new Entity('coldieBenchGlb')
engine.addEntity(coldieBenchGlb)
coldieBenchGlb.setParent(_scene)
coldieBenchGlb.addComponentOrReplace(gltfShape18)
const transform75 = new Transform({
  position: new Vector3(43.220890045166016, 0.09227490425109863, 36.15351486206055),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
coldieBenchGlb.addComponentOrReplace(transform75)

const coldieBenchGlb7 = new Entity('coldieBenchGlb7')
engine.addEntity(coldieBenchGlb7)
coldieBenchGlb7.setParent(_scene)
coldieBenchGlb7.addComponentOrReplace(gltfShape18)
const transform76 = new Transform({
  position: new Vector3(43.220890045166016, 0.09227490425109863, 32.65333557128906),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
coldieBenchGlb7.addComponentOrReplace(transform76)

const coldiePlantAltGlb9 = new Entity('coldiePlantAltGlb9')
engine.addEntity(coldiePlantAltGlb9)
coldiePlantAltGlb9.setParent(_scene)
coldiePlantAltGlb9.addComponentOrReplace(gltfShape20)
const transform77 = new Transform({
  position: new Vector3(35.03667068481445, 0.10942769050598145, 17.29388427734375),
  rotation: new Quaternion(8.637595609736152e-15, -0.9048753380775452, 1.0786953197339244e-7, 0.42567697167396545),
  scale: new Vector3(1.6627724170684814, 1.6627519130706787, 1.6627724170684814)
})
coldiePlantAltGlb9.addComponentOrReplace(transform77)

const coldiePlantAltGlb10 = new Entity('coldiePlantAltGlb10')
engine.addEntity(coldiePlantAltGlb10)
coldiePlantAltGlb10.setParent(_scene)
coldiePlantAltGlb10.addComponentOrReplace(gltfShape20)
const transform78 = new Transform({
  position: new Vector3(34.960060119628906, 0.10942769050598145, 28.247068405151367),
  rotation: new Quaternion(9.102714106567697e-15, -0.9999314546585083, 1.1920109699303794e-7, -0.011709480546414852),
  scale: new Vector3(1.6627764701843262, 1.6627519130706787, 1.6627764701843262)
})
coldiePlantAltGlb10.addComponentOrReplace(transform78)

const coldiePlantAltGlb11 = new Entity('coldiePlantAltGlb11')
engine.addEntity(coldiePlantAltGlb11)
coldiePlantAltGlb11.setParent(_scene)
coldiePlantAltGlb11.addComponentOrReplace(gltfShape20)
const transform79 = new Transform({
  position: new Vector3(9.941771507263184, 0.0902562141418457, 40.99965286254883),
  rotation: new Quaternion(3.342026303390492e-15, -0.7678924798965454, 9.153990276900004e-8, 0.6405786871910095),
  scale: new Vector3(1.2803088426589966, 1.2803092002868652, 1.2803088426589966)
})
coldiePlantAltGlb11.addComponentOrReplace(transform79)

const coldiePlantAltGlb12 = new Entity('coldiePlantAltGlb12')
engine.addEntity(coldiePlantAltGlb12)
coldiePlantAltGlb12.setParent(_scene)
coldiePlantAltGlb12.addComponentOrReplace(gltfShape20)
const transform80 = new Transform({
  position: new Vector3(9.941771507263184, 0.0902562141418457, 6.0718278884887695),
  rotation: new Quaternion(1.6696639340893884e-16, -0.9998480081558228, 1.1919115650016465e-7, 0.017434537410736084),
  scale: new Vector3(1.2803092002868652, 1.2803092002868652, 1.2803092002868652)
})
coldiePlantAltGlb12.addComponentOrReplace(transform80)

const coldieBenchGlb8 = new Entity('coldieBenchGlb8')
engine.addEntity(coldieBenchGlb8)
coldieBenchGlb8.setParent(_scene)
coldieBenchGlb8.addComponentOrReplace(gltfShape18)
const transform81 = new Transform({
  position: new Vector3(15.779367446899414, 3.6912262439727783, 4.044772148132324),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.000016212463379, 1, 1.000016212463379)
})
coldieBenchGlb8.addComponentOrReplace(transform81)

const coldieBenchGlb9 = new Entity('coldieBenchGlb9')
engine.addEntity(coldieBenchGlb9)
coldieBenchGlb9.setParent(_scene)
coldieBenchGlb9.addComponentOrReplace(gltfShape18)
const transform82 = new Transform({
  position: new Vector3(24.478023529052734, 4.225706100463867, 4.044772148132324),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000147819519043, 1, 1.0000147819519043)
})
coldieBenchGlb9.addComponentOrReplace(transform82)

const coldieBenchGlb13 = new Entity('coldieBenchGlb13')
engine.addEntity(coldieBenchGlb13)
coldieBenchGlb13.setParent(_scene)
coldieBenchGlb13.addComponentOrReplace(gltfShape18)
const transform83 = new Transform({
  position: new Vector3(33.21129608154297, 4.742791175842285, 4.044772148132324),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000128746032715, 1, 1.0000128746032715)
})
coldieBenchGlb13.addComponentOrReplace(transform83)

const coldieBenchGlb14 = new Entity('coldieBenchGlb14')
engine.addEntity(coldieBenchGlb14)
coldieBenchGlb14.setParent(_scene)
coldieBenchGlb14.addComponentOrReplace(gltfShape18)
const transform84 = new Transform({
  position: new Vector3(44.08099365234375, 5.50662899017334, 21.21968650817871),
  rotation: new Quaternion(-2.177062080483132e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(1.0000059604644775, 1, 1.0000059604644775)
})
coldieBenchGlb14.addComponentOrReplace(transform84)

const coldieBenchGlb15 = new Entity('coldieBenchGlb15')
engine.addEntity(coldieBenchGlb15)
coldieBenchGlb15.setParent(_scene)
coldieBenchGlb15.addComponentOrReplace(gltfShape18)
const transform85 = new Transform({
  position: new Vector3(44.08099365234375, 5.50662899017334, 24.93407440185547),
  rotation: new Quaternion(-2.177062080483132e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(1.0000059604644775, 1, 1.0000059604644775)
})
coldieBenchGlb15.addComponentOrReplace(transform85)

const coldiePlantAltGlb13 = new Entity('coldiePlantAltGlb13')
engine.addEntity(coldiePlantAltGlb13)
coldiePlantAltGlb13.setParent(_scene)
coldiePlantAltGlb13.addComponentOrReplace(gltfShape20)
const transform86 = new Transform({
  position: new Vector3(44.22590255737305, 5.47256326675415, 27.524194717407227),
  rotation: new Quaternion(-3.9611212022310025e-15, 0.47141826152801514, -5.619742893259172e-8, 0.8819099068641663),
  scale: new Vector3(1.1679935455322266, 1.1679911613464355, 1.1679935455322266)
})
coldiePlantAltGlb13.addComponentOrReplace(transform86)

const coldiePlantAltGlb14 = new Entity('coldiePlantAltGlb14')
engine.addEntity(coldiePlantAltGlb14)
coldiePlantAltGlb14.setParent(_scene)
coldiePlantAltGlb14.addComponentOrReplace(gltfShape20)
const transform87 = new Transform({
  position: new Vector3(44.22590255737305, 5.47256326675415, 18.814085006713867),
  rotation: new Quaternion(-2.8241914405371547e-15, -0.348036527633667, 4.148918719693029e-8, 0.9374809861183167),
  scale: new Vector3(1.167993426322937, 1.1679911613464355, 1.167993426322937)
})
coldiePlantAltGlb14.addComponentOrReplace(transform87)

const leftSidePaintings = new Entity('leftSidePaintings')
engine.addEntity(leftSidePaintings)
leftSidePaintings.setParent(_scene)
const transform88 = new Transform({
  position: new Vector3(25.036924362182617, 0, 5.813485145568848),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.219234824180603, 1.219234824180603, 1.219234824180603)
})
leftSidePaintings.addComponentOrReplace(transform88)
const gltfShape21 = new GLTFShape("models/left_side_paintings_rearranged_glb.glb")
gltfShape21.withCollisions = true
gltfShape21.isPointerBlocker = true
gltfShape21.visible = true
leftSidePaintings.addComponentOrReplace(gltfShape21)

const centerSidePainting = new Entity('centerSidePainting')
engine.addEntity(centerSidePainting)
centerSidePainting.setParent(_scene)
const transform89 = new Transform({
  position: new Vector3(29, 0.1918168067932129, 23),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.0354785919189453, 1.0354785919189453, 1.0354785919189453)
})
centerSidePainting.addComponentOrReplace(transform89)
const gltfShape22 = new GLTFShape("models/center_side_paintings2_rearranged_glb.glb")
gltfShape22.withCollisions = true
gltfShape22.isPointerBlocker = true
gltfShape22.visible = true
centerSidePainting.addComponentOrReplace(gltfShape22)

const museumProperCollid = new Entity('museumProperCollid')
engine.addEntity(museumProperCollid)
museumProperCollid.setParent(_scene)
const transform90 = new Transform({
  position: new Vector3(48, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
museumProperCollid.addComponentOrReplace(transform90)
const gltfShape23 = new GLTFShape("models/museum_proper_colliders_glb.glb")
gltfShape23.withCollisions = true
gltfShape23.isPointerBlocker = true
gltfShape23.visible = true
museumProperCollid.addComponentOrReplace(gltfShape23)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
script1.init(options)
script2.init(options)
script1.spawn(tools, {}, createChannel(channelId, tools, channelBus))
script2.spawn(triggerArea, {"enabled":true,"onEnter":[{"entityName":"tools","actionId":"move","values":{"target":"doorLeftGlb","x":0,"y":0,"z":-3.3,"speed":20,"relative":true,"onComplete":[{"entityName":"tools","actionId":"delay","values":{"timeout":5,"onTimeout":[{"entityName":"tools","actionId":"move","values":{"target":"doorLeftGlb","x":0,"y":0,"z":3.3,"speed":20,"relative":true,"onComplete":[]}}]}}]}},{"entityName":"tools","actionId":"move","values":{"target":"doorRightGlb","x":0,"y":0,"z":3.3,"speed":20,"relative":true,"onComplete":[{"entityName":"tools","actionId":"delay","values":{"timeout":5,"onTimeout":[{"entityName":"tools","actionId":"move","values":{"target":"doorRightGlb","x":0,"y":0,"z":-3.3,"speed":20,"relative":true,"onComplete":[{"entityName":"triggerArea","actionId":"enable","values":{}}]}}]}}]}},{"entityName":"triggerArea","actionId":"disable","values":{}}],"onLeave":[]}, createChannel(channelId, triggerArea, channelBus))